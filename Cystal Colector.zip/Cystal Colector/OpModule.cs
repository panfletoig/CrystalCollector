﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cystal_Colector
{
	internal static class OpModule
	{
		
	}
}
